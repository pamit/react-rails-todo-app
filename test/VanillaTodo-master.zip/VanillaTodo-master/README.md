VanillaTodo
===========
A todo list I hacked up in vanilla javscript. I wanted to do one without jQuery or any other framework/library.

Feel free to use this on any website/web-app and contribute if you'd like.